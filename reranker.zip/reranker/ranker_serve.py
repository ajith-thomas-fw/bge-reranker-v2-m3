import time
import ray
from ray import serve
import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer
from fastapi import FastAPI

# Load the model and tokenizer
model_name = "BAAI/bge-reranker-v2-m3"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForSequenceClassification.from_pretrained(model_name)

# ray.init()

# Create a FastAPI application to serve the Ray Serve deployment
app = FastAPI()


# Create a Ray Serve application to handle incoming requests
@serve.deployment
@serve.ingress(app)
class Reranker:
    def __init__(self):
        self.model = model
        self.tokenizer = tokenizer

    @app.post("/rerank")
    def new_rank(self, query, candidates):
        # Tokenize the query and candidates
        input_ids = self.tokenizer(
            query, candidates, padding=True,
            truncation=True, return_tensors="pt"
        )

        # Get the model's predictions
        with torch.no_grad():
            outputs = self.model(**input_ids)
            logits = outputs.logits

        # Rank the candidates based on the logits
        ranked_candidates = [
            (candidates[i], logits[0, i].item())
            for i in range(len(candidates))
        ]
        ranked_candidates.sort(key=lambda x: x[1], reverse=True)

        return ranked_candidates


# Deploy the application to Ray Serve
reranker_app = Reranker.bind()
time.sleep(10)
# serve.run(reranker_app)

