from ray import serve
from fastapi import FastAPI
from FlagEmbedding import FlagReranker

model = FlagReranker(
    'BAAI/bge-reranker-v2-m3',
    use_fp16=True
)

app = FastAPI()


@serve.deployment(
    num_replicas=1,
    ray_actor_options={"num_cpus": 1, "num_gpus": 0}
)
@serve.ingress(app)
class Reranker:
    def __init__(self):
        self.model = model

    @app.post("/rerank")
    def new_rank(self, query, candidates):
        scores = []
        for candidate in candidates:
            score = self.model.compute_score([query, candidate])
            scores.append(score)
        return scores


reranker_app = Reranker.bind()
