from ray import serve
from fastapi import FastAPI
from FlagEmbedding import FlagReranker

model = FlagReranker(
    'BAAI/bge-reranker-v2-m3'
)

app = FastAPI()


@serve.deployment(
    num_replicas=1,
    ray_actor_options={"num_cpus": 0, "num_gpus": 1}
)
@serve.ingress(app)
class Reranker:
    def __init__(self):
        self.model = model

    @app.post("/rerank")
    def new_rank(self, query, candidates):
        scores = []
        for candidate in candidates:
            score = self.model.compute_score([query, candidate])
            scores.append(score)
        return scores


reranker_app = Reranker.bind()

# create a post request for the above deployment
# curl -X 'POST' \
#   'http://localhost:8000/rerank' \
#   -H 'accept: application/json' \
#   -H 'Content-Type: application/json' \
#   -d '{
#   "query": "What is the capital of France?",
#   "candidates": ["Paris", "London", "Berlin"]
# }'
